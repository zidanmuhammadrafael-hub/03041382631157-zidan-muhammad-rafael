# ==============================================================================
# UTS Dasar Komputer dan Pemrograman - Mini Project
# Kelompok F : Informasi/Data - Analisis dan Klasifikasi Data
# ==============================================================================

# 1. Function untuk menentukan kategori/status dari satu nilai data
def kategori(nilai):
    if nilai < 60:
        return "RENDAH"
    elif nilai < 80:
        return "SEDANG"
    else:
        return "TINGGI"

# 2. Function untuk menghitung jumlah data pada masing-masing kategori
def hitung_kategori(data):
    jml_rendah = 0
    jml_sedang = 0
    jml_tinggi = 0
    
    for n in data:
        status = kategori(n)
        if status == "RENDAH":
            jml_rendah += 1
        elif status == "SEDANG":
            jml_sedang += 1
        else:
            jml_tinggi += 1
            
    return jml_rendah, jml_sedang, jml_tinggi

# 3. Function untuk menghitung nilai rata-rata dari seluruh data
def rata_rata(data):
    total_nilai = 0
    for n in data:
        total_nilai += n
    return total_nilai / len(data)

# 4. Function untuk mencari nilai maksimum dan minimum dari seluruh data
def cari_maks_min(data):
    nilai_maks = data[0]
    nilai_min = data[0]
    for n in data:
        if n > nilai_maks:
            nilai_maks = n
        if n < nilai_min:
            nilai_min = n
    return nilai_maks, nilai_min


# ==============================================================================
# PROGRAM UTAMA (MAIN PROGRAM)
# ==============================================================================

# 15 Data Inti (sesuai soal Kelompok F) + 5 Data Tambahan (urutan ke-16 s.d. 20)
data_nilai = [
    42, 55, 61, 68, 73, 79, 82, 87, 91, 64, 58, 76, 84, 49, 95,  # 15 Data Inti
    59, 60, 80, 35, 100                                          # 5 Data Tambahan
]

print("===== MONITORING & KLASIFIKASI DATA (KELOMPOK F) =====")
nomor = 1
for nilai in data_nilai:
    status_data = kategori(nilai)
    print(f"{nomor:02d} | Nilai = {nilai:3d} -> {status_data}")
    nomor += 1

# Menghitung statistik dan ringkasan akhir
total_data = len(data_nilai)
rendah, sedang, tinggi = hitung_kategori(data_nilai)
nilai_rata = rata_rata(data_nilai)
nilai_maksimum, nilai_minimum = cari_maks_min(data_nilai)

print("\n===== RINGKASAN =====")
print(f"Total data        : {total_data}")
print(f"Kategori RENDAH   : {rendah}")
print(f"Kategori SEDANG   : {sedang}")
print(f"Kategori TINGGI   : {tinggi}")
print(f"Rata-rata         : {nilai_rata:.2f}")
print(f"Maksimum          : {nilai_maksimum}")
print(f"Minimum           : {nilai_minimum}")
